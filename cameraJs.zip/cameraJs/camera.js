class Camera {
    constructor({canvasElement,videoElement,notSupportingLogic}) {
        this._canvasElement = canvasElement;
        this._videoElement = videoElement;
        this.notSupportingLogic = notSupportingLogic;
    }
    
    init() {
        const that = this;
        if (!("getUserMedia" in navigator.mediaDevices))
            navigator.mediaDevices.getUserMedia = function (constraints) {
                const getUserMedia = navigator.webkitGetUserMedia || navigator.mozGetUserMedia;
                if (getUserMedia)
                    return Promise.reject(new Error("getUserMedia in not implemented"))

                return new Promise(function (resolve,reject) {
                    getUserMedia.call(navigator,constraints,resolve,reject)
                })
            }

        navigator.mediaDevices.getUserMedia({video: true})
            .then(function (stream) {
                that._videoElement.srcObject = stream;
            })
            .catch(function (error) {
                that.notSupportingLogic(error);
            })
    }
    _URItoBlob(dataURI) {
        const byteString = atob(dataURI.split(',')[1]);
        const mimeString = dataURI.split(',')[0].split(':')[1].split(";")[0];
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);

        for (let i = 0;i < byteString.length;i++)
            ia[i] = byteString.charCodeAt(i);

        return new Blob([ab],{
            type: mimeString
        })
    }
    createCanvasImage() {
        const ctx = this._canvasElement.getContext("2d");
        ctx.drawImage(this._videoElement, 0, 0, canvas.width, this._videoElement.videoHeight / (this._videoElement.videoWidth / canvas.width));
        this._videoElement.srcObject.getVideoTracks().forEach(function (track) {
            track.stop();
        })
    }
    exportImageBlob() {
        return this._URItoBlob(canvasElement.toDataURL());
    }
}